// JavaScript source code
const Covid19_blockchain = artifacts.require("Covid19_blockchain");

module.exports = function (deployer) {
    deployer.deploy(Covid19_blockchain);
};
